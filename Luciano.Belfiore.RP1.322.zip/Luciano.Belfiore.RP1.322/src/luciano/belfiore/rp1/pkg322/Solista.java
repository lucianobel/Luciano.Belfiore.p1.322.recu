package luciano.belfiore.rp1.pkg322;

public class Solista extends Presentacion implements Tocable, Animable {
    private String instrumentoPrincipal;

    public Solista(String nombre, String escenario, TipoEscenario tipoEscenario, String instrumentoPrincipal) {
        super(nombre, escenario, tipoEscenario);
        this.instrumentoPrincipal = instrumentoPrincipal;
    }

    public String getInstrumentoPrincipal() {
        return instrumentoPrincipal;
    }

    @Override
    public void tocarEnVivo() {
        System.out.println("El solista " + getNombre() + " esta tocando en vivo su instrumento " + instrumentoPrincipal + " en el escenario " + getEscenario() + ".");
    }

    @Override
    public void animarPublico() {
        System.out.println("El solista " + getNombre() + " esta animando al publico en el escenario " + getEscenario() + ".");
    }

    @Override
    public String getTipoPresentacion() {
        return "Solista";
    }
}
