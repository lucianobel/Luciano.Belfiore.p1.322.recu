package luciano.belfiore.rp1.pkg322;

import java.util.*;

public class Recital {
    private List<Presentacion> presentaciones = new ArrayList<>();

    public void agregarPresentacion(Presentacion p) throws PresentacionExistenteException {
        for (Presentacion pres : presentaciones) {
            if (pres.getNombre().equals(p.getNombre()) &&
                pres.getEscenario().equals(p.getEscenario())) {
                throw new PresentacionExistenteException("Ya existe una presentacion con ese nombre y escenario.");
            }
        }
        presentaciones.add(p);
    }

    public void mostrarPresentaciones() {
        for (Presentacion p : presentaciones) {
            System.out.print("Nombre: " + p.getNombre() +
                " | Escenario: " + p.getEscenario() +
                " | Tipo de Escenario: " + p.getTipoEscenario() +
                " | Tipo de Presentacion: " + p.getTipoPresentacion());

            if (p instanceof Banda) {
                System.out.print(" | Integrantes max: " + ((Banda)p).getIntegrantesMax());
            }
            if (p instanceof Solista) {
                System.out.print(" | Instrumento principal: " + ((Solista)p).getInstrumentoPrincipal());
            }
            if (p instanceof Dj) {
                System.out.print(" | Estilo musical: " + ((Dj)p).getEstiloMusical());
            }
            System.out.println();
        }
    }

    public void tocarEnVivo() throws AccionNoPermitidaException {
        for (Presentacion p : presentaciones) {
            if (p instanceof Tocable) {
                ((Tocable)p).tocarEnVivo();
            } else {
                System.out.println("Error: La presentacion '" + p.getNombre() + "' no puede tocar en vivo.");
            }
        }
    }

    public void animarPublico() throws AccionNoPermitidaException {
        for (Presentacion p : presentaciones) {
            if (p instanceof Animable) {
                ((Animable)p).animarPublico();
            } else {
                System.out.println("Error: La presentacion '" + p.getNombre() + "' no puede animar al publico.");
            }
        }
    }

    public List<Presentacion> filtrarPorTipoEscenario(TipoEscenario tipo) {
        List<Presentacion> filtradas = new ArrayList<>();
        for (Presentacion p : presentaciones) {
            if (p.getTipoEscenario() == tipo) {
                filtradas.add(p);
            }
        }
        for (Presentacion p : filtradas) {
            System.out.println("Nombre: " + p.getNombre() + "  Escenario: " + p.getEscenario());
        }
        return filtradas;
    }

    public int eliminarPresentacionesPorTipo(String tipoPresentacion) {
        int count = 0;
        Iterator<Presentacion> it = presentaciones.iterator();
        while (it.hasNext()) {
            Presentacion p = it.next();
            if (p.getTipoPresentacion().equalsIgnoreCase(tipoPresentacion)) {
                it.remove();
                count++;
            }
        }
        System.out.println("Presentaciones eliminadas del tipo " + tipoPresentacion + ": " + count);
        return count;
    }
}
