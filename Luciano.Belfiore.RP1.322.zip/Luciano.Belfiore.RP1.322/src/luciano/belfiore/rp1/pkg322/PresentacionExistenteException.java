package luciano.belfiore.rp1.pkg322;

public class PresentacionExistenteException extends Exception {
    
    public PresentacionExistenteException(String msg) {
        super(msg);
    }
}
