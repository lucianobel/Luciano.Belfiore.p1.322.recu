package luciano.belfiore.rp1.pkg322;

public interface Tocable {
    void tocarEnVivo() throws AccionNoPermitidaException;
}
