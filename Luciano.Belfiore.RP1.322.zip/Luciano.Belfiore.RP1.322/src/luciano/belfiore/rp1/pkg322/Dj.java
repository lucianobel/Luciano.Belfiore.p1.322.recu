package luciano.belfiore.rp1.pkg322;

public class Dj extends Presentacion implements Animable {
    private String estiloMusical;

    public Dj(String nombre, String escenario, TipoEscenario tipoEscenario, String estiloMusical) {
        super(nombre, escenario, tipoEscenario);
        this.estiloMusical = estiloMusical;
    }

    public String getEstiloMusical() {
        return estiloMusical;
    }

    @Override
    public void animarPublico() {
        System.out.println("El Dj " + getNombre() + " esta animando al publico con musica " + estiloMusical + " en el escenario " + getEscenario() + ".");
    }

    @Override
    public String getTipoPresentacion() {
        return "Dj";
    }
}
