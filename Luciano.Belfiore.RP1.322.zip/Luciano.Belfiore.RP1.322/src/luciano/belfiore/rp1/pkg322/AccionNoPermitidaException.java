package luciano.belfiore.rp1.pkg322;

public class AccionNoPermitidaException extends Exception {
    
    public AccionNoPermitidaException(String msg) {
        super(msg);
    }
}
