package luciano.belfiore.rp1.pkg322;

public abstract class Presentacion {
    
    private String nombre;
    private String escenario;
    private TipoEscenario tipoEscenario;

    public Presentacion(String nombre, String escenario, TipoEscenario tipoEscenario) {
        this.nombre = nombre;
        this.escenario = escenario;
        this.tipoEscenario = tipoEscenario;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEscenario() {
        return escenario;
    }

    public TipoEscenario getTipoEscenario() {
        return tipoEscenario;
    }

    public abstract String getTipoPresentacion();
}
