package luciano.belfiore.rp1.pkg322;

public interface Animable {
    void animarPublico() throws AccionNoPermitidaException;
}
