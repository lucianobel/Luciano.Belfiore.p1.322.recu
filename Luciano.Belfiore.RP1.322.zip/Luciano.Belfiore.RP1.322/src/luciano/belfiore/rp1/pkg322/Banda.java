package luciano.belfiore.rp1.pkg322;

public class Banda extends Presentacion implements Tocable {
    private int integrantesMax;

    public Banda(String nombre, String escenario, TipoEscenario tipoEscenario, int integrantesMax) {
        super(nombre, escenario, tipoEscenario);
        this.integrantesMax = integrantesMax;
    }

    public int getIntegrantesMax() {
        return integrantesMax;
    }

    @Override
    public void tocarEnVivo() {
        System.out.println("La banda " + getNombre() + " esta tocando en vivo en el escenario " + getEscenario() + ".");
    }

    @Override
    public String getTipoPresentacion() {
        return "Banda";
    }
}
