package luciano.belfiore.rp1.pkg322;

public class LucianoBelfioreRP1322 {

    public static void main(String[] args) throws AccionNoPermitidaException {
        
        Recital recital = new Recital();

        // 1. Agregar presentaciones al sistema
        System.out.println("-- 1. Agregar Presentaciones --");
        try {
            Banda banda = new Banda("Los Relampagos", "Principal", TipoEscenario.INTERIOR, 6);
            recital.agregarPresentacion(banda);

            // Intento de agregar la misma banda (mismo nombre y escenario)
            Banda bandaDuplicada = new Banda("Los Relampagos", "Principal", TipoEscenario.INTERIOR, 6);
            recital.agregarPresentacion(bandaDuplicada);
        } catch (PresentacionExistenteException e) {
            System.out.println("ERROR: " + e.getMessage());
        }

        // Agregar más presentaciones
        Solista solista = new Solista("Sofia Shine", "Principal", TipoEscenario.INTERIOR, "Violin");
        Dj dj = new Dj("Thunder", "Al aire libre", TipoEscenario.EXTERIOR, "Techno");
        try {
            recital.agregarPresentacion(solista);
            recital.agregarPresentacion(dj);
        } catch (PresentacionExistenteException e) {
            System.out.println("No debería ocurrir aquí: " + e.getMessage());
        }

        // 2. Mostrar presentaciones registradas
        System.out.println("\n-- 2. Mostrar Presentaciones Registradas --");
        recital.mostrarPresentaciones();

        // 3. Show en vivo y animar al público
        System.out.println("\n-- 3. Show en Vivo --");
        recital.tocarEnVivo();

        System.out.println("\n-- 3. Animar al Publico --");
        recital.animarPublico();

        // 4. Filtrar por tipo de escenario
        System.out.println("\n-- 4. Filtrar por Escenario INTERIOR --");
        recital.filtrarPorTipoEscenario(TipoEscenario.INTERIOR);

        System.out.println("\n-- 4. Filtrar por Escenario EXTERIOR --");
        recital.filtrarPorTipoEscenario(TipoEscenario.EXTERIOR);

        // 5. Eliminar Presentaciones por Tipo
        System.out.println("\n-- 5. Eliminar Presentaciones por Tipo: DJ --");
        int eliminados = recital.eliminarPresentacionesPorTipo("Dj");

        System.out.println("\n-- Mostrar Presentaciones Restantes --");
        recital.mostrarPresentaciones();
    }
}
