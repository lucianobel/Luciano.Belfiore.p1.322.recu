package luciano.belfiore.rp1.pkg322;

public enum TipoEscenario {
    INTERIOR,
    EXTERIOR;
}
