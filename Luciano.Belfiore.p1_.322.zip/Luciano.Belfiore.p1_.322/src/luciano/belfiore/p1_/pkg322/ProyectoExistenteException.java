package luciano.belfiore.p1_.pkg322;

public class ProyectoExistenteException extends RuntimeException{

    private final Proyecto proyectoExistente;

    public ProyectoExistenteException(String mensaje) {
        super(mensaje);
        this.proyectoExistente = null;
    }

    public ProyectoExistenteException(String mensaje, Proyecto proyectoExistente) {
        super(mensaje);
        this.proyectoExistente = proyectoExistente;
    }

    public Proyecto getProyectoExistente() {
        return proyectoExistente;
    }
}
