package luciano.belfiore.p1_.pkg322;

public enum TipoAnalisis {
    DESCRIPTIVO,
    INFERENCIAL,
    PREDICTIVO
}

