package luciano.belfiore.p1_.pkg322;


public class SistemaVisualizacion extends Proyecto{
    private int cantidadGraficos; // > 0

    public SistemaVisualizacion(String nombre, String equipoResponsable, EstadoProyecto estadoActual, int cantidadGraficos) {
        super(nombre, equipoResponsable, estadoActual);
        this.cantidadGraficos = cantidadGraficos;
    }

    public int getCantidadGraficos() {
        return cantidadGraficos;
    }

    public void setCantidadGraficos(int cantidadGraficos) {
        this.cantidadGraficos = cantidadGraficos;
    }

    @Override
    public String toString() {
        return String.format("%s, Tipo: SistemaVisualizacion, CantidadGraficos: %d",
                super.toString(), cantidadGraficos);
    }
    
    
}