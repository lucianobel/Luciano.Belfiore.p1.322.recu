package luciano.belfiore.p1_.pkg322;

public abstract class Proyecto {
    private final String nombre ;
    private final String equipoResponsable;
    private EstadoProyecto estadoActual;

    public Proyecto(String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
        if (nombre == null || nombre.isBlank()) throw new IllegalArgumentException("ERROR \nNombre esta vacio");
        if (equipoResponsable == null || equipoResponsable.isBlank())
            throw new IllegalArgumentException("ERROR \nEquipo responsable esta vacio");
        this.nombre = nombre;
        this.equipoResponsable = equipoResponsable;
        this.estadoActual = estadoActual;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEquipoResponsable() {
        return equipoResponsable;
    }

    public EstadoProyecto getEstadoActual() {
        return estadoActual;
    }

    public void setEstadoActual(EstadoProyecto estadoActual) {
        this.estadoActual = estadoActual;
    }

    @Override
    public String toString() {
        return "Proyecto{" + "nombre=" + nombre + ", equipoResponsable=" + equipoResponsable + ", estadoActual=" + estadoActual + '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Proyecto)) return false;
        Proyecto otro = (Proyecto) o;
        return nombre.equalsIgnoreCase(otro.nombre) &&
               equipoResponsable.equalsIgnoreCase(otro.equipoResponsable);
    }

    @Override
    public int hashCode() {
        return (nombre.toLowerCase() + "|" + equipoResponsable.toLowerCase()).hashCode();
    }
    
}
