package luciano.belfiore.p1_.pkg322;

public class LucianoBelfioreP1_322 {
    
    public static void main(String[] args) {
        RegistroProyectos registro = new RegistroProyectos();
        
        AnalisisEstadistico a1 = new AnalisisEstadistico("AnalisisVentas", "EquipoBeta", EstadoProyecto.EN_DESARROLLO, TipoAnalisis.DESCRIPTIVO);
        ModeloMachineLearning m1 = new ModeloMachineLearning("aaaa", "EquipoAlpha", EstadoProyecto.EN_DESARROLLO, 72.5);
        SistemaVisualizacion s1 = new SistemaVisualizacion("DashVentas", "EquipoGamma", EstadoProyecto.EN_DESARROLLO, 5);
        try {
            registro.agregarProyecto(m1);
            registro.agregarProyecto(a1);
            registro.agregarProyecto(s1);

            System.out.println();
            registro.mostrarProyectos();

            System.out.println("\n=== Actualizar resultados de proyectos ===");
            registro.actualizarResultadosProyectos();

            System.out.println("\n=== Actualizar estado a ENTRENANDO_MODELO ===");
            registro.actualizarEstadoProyectos(EstadoProyecto.ENTRENANDO_MODELO);

            System.out.println("\n=== Intentar actualizar a null ===");
            registro.actualizarEstadoProyectos(null);

            System.out.println("\n=== Intentar agregar duplicado ===");
            registro.agregarProyecto(new ModeloMachineLearning("ClasificadorA", "EquipoAlpha", EstadoProyecto.EN_DESARROLLO, 80.0));
        } catch (ProyectoExistenteException ex) {
            System.out.println("Error: " + ex.getMessage());
            if (ex.getProyectoExistente() != null) {
                System.out.println("Proyecto existente: " + ex.getProyectoExistente());
            }
        } catch (IllegalArgumentException ex) {
            System.out.println("Argumento inválido: " + ex.getMessage());
        }
    }
}
    
