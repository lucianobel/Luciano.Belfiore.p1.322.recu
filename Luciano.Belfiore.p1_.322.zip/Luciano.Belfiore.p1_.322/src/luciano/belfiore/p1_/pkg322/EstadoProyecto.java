package luciano.belfiore.p1_.pkg322;

public enum EstadoProyecto {
    EN_DESARROLLO,
    ENTRENANDO_MODELO,
    FINALIZADO
}
