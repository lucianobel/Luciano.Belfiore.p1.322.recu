package luciano.belfiore.p1_.pkg322;

public interface Actualizable {
    void actualizarResultados();
}
