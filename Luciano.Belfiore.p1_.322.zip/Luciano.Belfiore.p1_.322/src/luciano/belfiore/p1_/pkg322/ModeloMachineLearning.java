package luciano.belfiore.p1_.pkg322;

import java.util.Random;

public class ModeloMachineLearning extends Proyecto implements Actualizable {
    
    private double porcentajePrecision; // 0.0 - 100.0
    private final Random rnd = new Random();
    
    public ModeloMachineLearning(String nombre, String equipoResponsable, EstadoProyecto estadoActual, double porcentajePrecision) {
        super(nombre, equipoResponsable, estadoActual);
        setPorcentajePrecision(porcentajePrecision);
    }

    public double getPorcentajePrecision() {
        return porcentajePrecision;
    }

    public void setPorcentajePrecision(double porcentajePrecision) {
        if (porcentajePrecision < 0.0 || porcentajePrecision > 100.0)
            throw new IllegalArgumentException("Porcentaje de precisión debe estar entre 0 y 100");
        this.porcentajePrecision = porcentajePrecision;
    }
    
    @Override
    public void actualizarResultados() {
        double incremento = rnd.nextDouble() * 5.0;
        double anterior = this.porcentajePrecision;
        this.porcentajePrecision = Math.min(100.0, this.porcentajePrecision + incremento);
        System.out.printf("Modelo '%s' (%s) - precisión: %.2f -> %.2f%n",
                getNombre(), getEquipoResponsable(), anterior, this.porcentajePrecision);
    }

    @Override
    public String toString() {
        return String.format("%s, Tipo: ModeloMachineLearning, Precisión: %.2f%%",
                super.toString(), porcentajePrecision);
    }
        
}
