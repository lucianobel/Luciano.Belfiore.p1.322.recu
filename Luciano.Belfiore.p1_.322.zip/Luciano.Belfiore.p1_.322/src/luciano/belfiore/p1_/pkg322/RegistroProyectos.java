package luciano.belfiore.p1_.pkg322;

import java.util.ArrayList;
import java.util.List;

public class RegistroProyectos {

    private final List<Proyecto> proyectos = new ArrayList<>();

    public void agregarProyecto(Proyecto proyecto) throws ProyectoExistenteException {
        if (proyecto == null) throw new IllegalArgumentException("Proyecto no puede ser nulo");

        for (Proyecto p : proyectos) {
            if (p.equals(proyecto)) {
                throw new ProyectoExistenteException(String.format(
                    "Ya existe un proyecto con nombre '%s' y equipo '%s'",
                    proyecto.getNombre(), proyecto.getEquipoResponsable()), p);
            }
        }
        proyectos.add(proyecto);
    }

    public void mostrarProyectos() {
        if (proyectos.isEmpty()) {
            System.out.println("No hay proyectos registrados.");
            return;
        }
        System.out.println("Proyectos registrados:");
        for (Proyecto p : proyectos) {
            System.out.println("- " + p.toString());
        }
    }

    public void actualizarResultadosProyectos() {
        if (proyectos.isEmpty()) {
            System.out.println("No hay proyectos registrados.");
            return;
        }
        for (Proyecto p : proyectos) {
            if (p instanceof Actualizable) {
                ((Actualizable) p).actualizarResultados();
            } else {
                System.out.printf("Proyecto '%s' (%s) no puede actualizar resultados directamente (SistemaVisualizacion).%n",
                        p.getNombre(), p.getEquipoResponsable());
            }
        }
    }

    public void actualizarEstadoProyectos(EstadoProyecto nuevoEstado) {
        if (nuevoEstado == null) {
            System.out.println("No se realizo ninguna modificacion");
            return;
        }
        if (proyectos.isEmpty()) {
            System.out.println("No hay proyectos registrados.");
            return;
        }
        int contadorCambios = 0;
        for (Proyecto p : proyectos) {
            EstadoProyecto anterior = p.getEstadoActual();
            if (anterior != nuevoEstado) {
                p.setEstadoActual(nuevoEstado);
                contadorCambios++;
                System.out.printf("Proyecto '%s' (%s): Estado %s -> %s%n",
                        p.getNombre(), p.getEquipoResponsable(), anterior, nuevoEstado);
            }
        }
        if (contadorCambios == 0) {
            System.out.println("No se realizo ninguna modificacion.");
        } else {
            System.out.printf("Total de proyectos actualizados: %d%n", contadorCambios);
        }
    }

    public List<Proyecto> getProyectos() {
        return new ArrayList<>(proyectos);
    }
}
