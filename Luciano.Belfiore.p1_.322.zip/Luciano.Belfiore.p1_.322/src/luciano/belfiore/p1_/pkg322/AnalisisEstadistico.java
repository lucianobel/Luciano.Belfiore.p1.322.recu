package luciano.belfiore.p1_.pkg322;

public class AnalisisEstadistico extends Proyecto implements Actualizable{
    
    private TipoAnalisis tipoAnalisis;
    
    public AnalisisEstadistico(String nombre, String equipoResponsable, EstadoProyecto estadoActual, TipoAnalisis tipoAnalisis) {
        super(nombre, equipoResponsable, estadoActual);
        if (tipoAnalisis == null) throw new IllegalArgumentException("Tipo de analisis no puede ser nulo");
        this.tipoAnalisis = tipoAnalisis;
    }  


    public TipoAnalisis getTipoAnalisis() {
        return tipoAnalisis;
    }

    public void setTipoAnalisis(TipoAnalisis tipoAnalisis) {
        this.tipoAnalisis = tipoAnalisis;
    }
    
    @Override
    public void actualizarResultados() {
        System.out.printf("Analisis '%s' (%s) de tipo %s: resultados actualizados.%n",
                getNombre(), getEquipoResponsable(), tipoAnalisis);
    }

    @Override
    public String toString() {
        return String.format("%s, Tipo: AnalisisEstadistico, TipoAnalisis: %s",
                super.toString(), tipoAnalisis);
    }
}